import axios from "axios";

export default api = axios.create({
    baseURL:'https://rega.apputumayo.gov.co'
})